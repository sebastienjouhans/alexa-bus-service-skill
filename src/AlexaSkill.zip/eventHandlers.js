'use strict';

var registerEventHandlers = function (eventHandlers, skillContext) {
    eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
        
    };

    eventHandlers.onLaunch = function (launchRequest, session, response) {
        
    };
};
exports.register = registerEventHandlers;
